<?php


$db=new mysqli("localhost","root","","stpshop")

?>